#include <WiFi.h>
#include <WebServer.h>

const char* AP_SSID = "ESP32-Chat";
const char* AP_PASSWORD = "12345678";

WebServer server(80);

struct Message {
  String username;
  String text;
  unsigned long time;
};

Message messages[50];
int messageCount = 0;

struct User {
  String name;
  IPAddress ip;
  unsigned long lastSeen;
};

User users[10];
int userCount = 0;

const char MAIN_PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ESP32 Chat</title>

<style>
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: #101114;
  color: #eee;
}

header {
  background: #181a20;
  padding: 15px 20px;
  border-bottom: 1px solid #2b2e36;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.logo {
  font-size: 21px;
  font-weight: bold;
}

.status {
  color: #55e889;
  font-size: 14px;
}

.container {
  display: flex;
  height: calc(100vh - 61px);
}

.chat {
  flex: 1;
  display: flex;
  flex-direction: column;
}

.messages {
  flex: 1;
  overflow-y: auto;
  padding: 20px;
}

.message {
  margin-bottom: 15px;
  max-width: 700px;
}

.message .name {
  color: #6ca8ff;
  font-weight: bold;
  font-size: 14px;
}

.message .text {
  background: #1b1e25;
  padding: 10px 13px;
  border-radius: 10px;
  margin-top: 4px;
  display: inline-block;
  word-break: break-word;
}

.message .time {
  color: #777;
  font-size: 11px;
  margin-left: 6px;
}

.input-area {
  padding: 15px;
  background: #181a20;
  border-top: 1px solid #2b2e36;
  display: flex;
  gap: 10px;
}

input {
  background: #101114;
  border: 1px solid #333741;
  color: white;
  padding: 12px;
  border-radius: 8px;
  outline: none;
}

#message {
  flex: 1;
}

button {
  border: none;
  background: #3978ff;
  color: white;
  padding: 0 20px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
}

button:hover {
  background: #2867ed;
}

.sidebar {
  width: 230px;
  background: #15171c;
  border-left: 1px solid #2b2e36;
  padding: 18px;
}

.sidebar h3 {
  margin-top: 0;
}

.user {
  padding: 8px;
  background: #1d2027;
  border-radius: 7px;
  margin-bottom: 7px;
}

.online {
  color: #55e889;
  margin-right: 5px;
}

.login {
  position: fixed;
  inset: 0;
  background: #101114;
  display: flex;
  justify-content: center;
  align-items: center;
}

.login-box {
  background: #181a20;
  padding: 30px;
  border-radius: 15px;
  width: 90%;
  max-width: 400px;
}

.login-box h1 {
  margin-top: 0;
}

.login-box input {
  width: 100%;
  margin-bottom: 12px;
}

.login-box button {
  width: 100%;
  height: 42px;
}

@media(max-width: 650px) {
  .sidebar {
    display: none;
  }
}
</style>
</head>

<body>

<div class="login" id="login">
  <div class="login-box">
    <h1>ESP32 Chat</h1>
    <p>Wähle einen Benutzernamen.</p>

    <input
      id="username"
      maxlength="20"
      placeholder="Dein Name"
      autocomplete="off"
    >

    <button onclick="joinChat()">Beitreten</button>
  </div>
</div>

<header>
  <div class="logo">💬 ESP32 Chat</div>
  <div class="status">
    ● <span id="onlineCount">0</span> online
  </div>
</header>

<div class="container">

  <div class="chat">

    <div class="messages" id="messages"></div>

    <div class="input-area">

      <input
        id="message"
        placeholder="Nachricht schreiben..."
        maxlength="200"
        autocomplete="off"
      >

      <button onclick="sendMessage()">Senden</button>

    </div>

  </div>

  <div class="sidebar">

    <h3>Online</h3>

    <div id="users"></div>

  </div>

</div>

<script>

let myName = "";

function joinChat() {

  const input = document.getElementById("username");

  let name = input.value.trim();

  if (!name) {
    alert("Bitte einen Namen eingeben.");
    return;
  }

  myName = name;

  document.getElementById("login").style.display = "none";

  fetch("/join?name=" + encodeURIComponent(myName));

  loadMessages();
  loadUsers();

}

async function sendMessage() {

  const input = document.getElementById("message");

  const text = input.value.trim();

  if (!text || !myName) return;

  input.value = "";

  await fetch(
    "/send?name=" +
    encodeURIComponent(myName) +
    "&text=" +
    encodeURIComponent(text)
  );

  loadMessages();

}

async function loadMessages() {

  try {

    const response = await fetch("/messages");

    const data = await response.json();

    const container = document.getElementById("messages");

    container.innerHTML = "";

    data.forEach(msg => {

      const div = document.createElement("div");

      div.className = "message";

      div.innerHTML =
        '<span class="name">' +
        escapeHtml(msg.name) +
        '</span>' +

        '<span class="time">' +
        msg.time +
        '</span>' +

        '<div class="text">' +
        escapeHtml(msg.text) +
        '</div>';

      container.appendChild(div);

    });

    container.scrollTop = container.scrollHeight;

  } catch(e) {}

}

async function loadUsers() {

  try {

    const response = await fetch("/users");

    const data = await response.json();

    document.getElementById("onlineCount").textContent = data.length;

    const container = document.getElementById("users");

    container.innerHTML = "";

    data.forEach(user => {

      const div = document.createElement("div");

      div.className = "user";

      div.innerHTML =
        '<span class="online">●</span>' +
        escapeHtml(user);

      container.appendChild(div);

    });

  } catch(e) {}

}

function escapeHtml(text) {

  const div = document.createElement("div");

  div.textContent = text;

  return div.innerHTML;

}

document.getElementById("message").addEventListener(
  "keydown",
  function(event) {

    if (event.key === "Enter") {
      sendMessage();
    }

  }
);

setInterval(() => {

  if (myName) {
    loadMessages();
    loadUsers();
    fetch("/ping?name=" + encodeURIComponent(myName));
  }

}, 1000);

</script>

</body>
</html>
)rawliteral";


void addUser(String name, IPAddress ip) {

  for (int i = 0; i < userCount; i++) {

    if (users[i].name == name) {
      users[i].ip = ip;
      users[i].lastSeen = millis();
      return;
    }

  }

  if (userCount < 10) {

    users[userCount].name = name;
    users[userCount].ip = ip;
    users[userCount].lastSeen = millis();

    userCount++;

  }

}


void cleanupUsers() {

  unsigned long now = millis();

  for (int i = 0; i < userCount; i++) {

    if (now - users[i].lastSeen > 5000) {

      for (int j = i; j < userCount - 1; j++) {
        users[j] = users[j + 1];
      }

      userCount--;
      i--;

    }

  }

}


void handleRoot() {

  server.send_P(
    200,
    "text/html",
    MAIN_PAGE
  );

}


void handleJoin() {

  if (!server.hasArg("name")) {
    server.send(400, "text/plain", "Name fehlt");
    return;
  }

  String name = server.arg("name");

  name.trim();

  if (name.length() == 0) {
    server.send(400, "text/plain", "Name fehlt");
    return;
  }

  addUser(name, server.client().remoteIP());

  server.send(200, "text/plain", "OK");

}


void handlePing() {

  if (server.hasArg("name")) {

    addUser(
      server.arg("name"),
      server.client().remoteIP()
    );

  }

  server.send(200, "text/plain", "OK");

}


void handleSend() {

  if (!server.hasArg("name") ||
      !server.hasArg("text")) {

    server.send(400, "text/plain", "Fehlende Daten");
    return;

  }

  String name = server.arg("name");
  String text = server.arg("text");

  name.trim();
  text.trim();

  if (name.length() == 0 ||
      text.length() == 0) {

    server.send(400, "text/plain", "Leer");
    return;

  }

  if (messageCount >= 50) {

    for (int i = 0; i < 49; i++) {
      messages[i] = messages[i + 1];
    }

    messageCount = 49;

  }

  messages[messageCount].username = name;
  messages[messageCount].text = text;
  messages[messageCount].time = millis();

  messageCount++;

  addUser(
    name,
    server.client().remoteIP()
  );

  server.send(200, "text/plain", "OK");

}


void handleMessages() {

  String json = "[";

  for (int i = 0; i < messageCount; i++) {

    if (i > 0)
      json += ",";

    unsigned long seconds =
      messages[i].time / 1000;

    unsigned long minutes =
      seconds / 60;

    seconds %= 60;

    char timeString[10];

    sprintf(
      timeString,
      "%02lu:%02lu",
      minutes % 60,
      seconds
    );

    json += "{";
    json += "\"name\":\"";
    json += messages[i].username;
    json += "\",";
    json += "\"text\":\"";
    json += messages[i].text;
    json += "\",";
    json += "\"time\":\"";
    json += timeString;
    json += "\"";
    json += "}";

  }

  json += "]";

  server.send(
    200,
    "application/json",
    json
  );

}


void handleUsers() {

  cleanupUsers();

  String json = "[";

  for (int i = 0; i < userCount; i++) {

    if (i > 0)
      json += ",";

    json += "\"";
    json += users[i].name;
    json += "\"";

  }

  json += "]";

  server.send(
    200,
    "application/json",
    json
  );

}


void setup() {

  Serial.begin(115200);

  WiFi.mode(WIFI_AP);

  WiFi.softAP(
    AP_SSID,
    AP_PASSWORD
  );

  Serial.println();
  Serial.println("======================");
  Serial.println("ESP32 CHAT SERVER");
  Serial.println("======================");

  Serial.print("WLAN: ");
  Serial.println(AP_SSID);

  Serial.print("Passwort: ");
  Serial.println(AP_PASSWORD);

  Serial.print("IP: ");
  Serial.println(WiFi.softAPIP());

  server.on("/", handleRoot);
  server.on("/join", handleJoin);
  server.on("/ping", handlePing);
  server.on("/send", handleSend);
  server.on("/messages", handleMessages);
  server.on("/users", handleUsers);

  server.begin();

  Serial.println("Server gestartet!");

}


void loop() {

  server.handleClient();

  cleanupUsers();

}